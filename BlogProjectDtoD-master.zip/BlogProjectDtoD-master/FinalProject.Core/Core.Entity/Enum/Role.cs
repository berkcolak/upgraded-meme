﻿namespace FinalProject.Core.Core.Entity.Enum
{
    public enum Role
    {
        None = 0,
        Member = 1,
        Admin = 3,
        Article = 5,
        Editor = 7
    }
}
