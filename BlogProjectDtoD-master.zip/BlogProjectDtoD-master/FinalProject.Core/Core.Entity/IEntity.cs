﻿namespace FinalProject.Core.Core.Entity
{
   public interface IEntity<T>
    {
        T ID { get; set; }
    }
}
